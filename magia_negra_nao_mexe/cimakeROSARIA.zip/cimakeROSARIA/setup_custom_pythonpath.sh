#!/usr/bin/env sh
# generated from dynamic_reconfigure/cmake/setup_custom_pythonpath.sh.in

PYTHONPATH=/home/ubuntu/catkin_ws/devel/lib/python2.7/dist-packages:$PYTHONPATH
exec "$@"
